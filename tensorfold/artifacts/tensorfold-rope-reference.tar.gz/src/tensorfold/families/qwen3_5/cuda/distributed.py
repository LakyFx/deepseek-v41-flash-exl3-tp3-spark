"""Two-rank shards preserve packed rows and quantization-group boundaries, keeping row-parallel partials in fp32 until rank-ordered summation."""

from __future__ import annotations

from dataclasses import dataclass, replace
import os
from typing import Sequence

import torch
import torch.distributed as dist

from .weights import Attention, Config, GDN, Layer, QLinear, Weights

try:
    import triton
    import triton.language as tl
except ImportError:  # CPU hosts can inspect and test the partition map.
    triton = None
    tl = None


def _rank(rank: int, world_size: int) -> None:
    if world_size != 2 or rank not in (0, 1):
        raise ValueError("the CUDA partition map currently requires two ranks")


def output_rows(n: int, rank: int, world_size: int = 2,
                segments: Sequence[int] | None = None, block: int = 1,
                device: torch.device | str = "cpu") -> torch.Tensor:
    """Return rank-local indices in segment order, preserving concatenated GDN projections and complete attention query/gate head blocks."""

    _rank(rank, world_size)
    lengths = tuple(segments) if segments is not None else (n,)
    if sum(lengths) != n or any(v <= 0 or v % (world_size * block) for v in lengths):
        raise ValueError(f"output segments {lengths} do not split into {world_size} blocks of {block}")
    base = 0
    ranges = []
    for length in lengths:
        half = length // world_size
        ranges.append(torch.arange(base + rank * half, base + (rank + 1) * half, device=device))
        base += length
    return torch.cat(ranges)


def split_output(q: QLinear, rank: int, world_size: int = 2,
                 segments: Sequence[int] | None = None, block: int = 1) -> QLinear:
    """Column-parallel QLinear: each rank owns complete output rows."""

    if q.layout == "tiled":
        raise ValueError("split the checkpoint layout before tiling")
    rows = output_rows(q.n, rank, world_size, segments, block, q.weight.device)
    return QLinear(q.weight.index_select(0, rows).contiguous(),
                   q.scales.index_select(0, rows).contiguous() if q.scales is not None else None,
                   q.biases.index_select(0, rows).contiguous() if q.biases is not None else None,
                   layout=q.layout, gs=q.gs, bits=q.bits)


def split_input(q: QLinear, rank: int, world_size: int = 2) -> QLinear:
    """Row-parallel QLinear: each rank owns complete declared quantization groups."""

    _rank(rank, world_size)
    if q.layout == "dense":
        if q.k % world_size:
            raise ValueError("dense input width must divide into equal rank halves")
        half = q.k // world_size
        return QLinear(q.weight[:, rank * half:(rank + 1) * half].contiguous(), None, None,
                       layout="dense", gs=0, bits=0)
    if q.layout != "mlx":
        raise ValueError("split the checkpoint layout before tiling")
    from tensorfold.cuda.kernels.affine import input_slice

    (w0, w1), (g0, g1) = input_slice(q.k, q.bits, q.gs, rank, world_size)
    return QLinear(q.weight[:, w0:w1].contiguous(),
                   q.scales[:, g0:g1].contiguous(),
                   q.biases[:, g0:g1].contiguous(), gs=q.gs, bits=q.bits)


def local_input(x: torch.Tensor, rank: int, world_size: int = 2, *, group_size: int = 64) -> torch.Tensor:
    """Select the activation columns corresponding to ``split_input``."""

    _rank(rank, world_size)
    if group_size not in (1, 32, 64, 128) or x.ndim != 2 or x.shape[1] % (group_size * world_size):
        raise ValueError("activation input must be 2-D and group-aligned")
    half = x.shape[1] // world_size
    return x[:, rank * half:(rank + 1) * half].contiguous()


@dataclass
class LayerShard:
    """Layer weights with local heads and MLP width; norms remain replicated."""

    layer: Layer
    rank: int
    world_size: int
    q_heads: int
    kv_heads: int
    k_heads: int
    v_heads: int


def split_layer(layer: Layer, cfg: Config, rank: int, world_size: int = 2) -> LayerShard:
    """Shard one layer along its head and MLP axes without changing checkpoint words."""

    _rank(rank, world_size)
    if any(v % world_size for v in (cfg.heads, cfg.kv_heads, cfg.k_heads, cfg.v_heads,
                                    cfg.intermediate)):
        raise ValueError("head count and MLP width must be divisible by rank count")
    attn = None
    if layer.attn is not None:
        a = layer.attn
        attn = Attention(q=split_output(a.q, rank, block=2 * cfg.head_dim),
                         k=split_output(a.k, rank, block=cfg.head_dim),
                         v=split_output(a.v, rank, block=cfg.head_dim),
                         o=split_input(a.o, rank), q_norm=a.q_norm, k_norm=a.k_norm)
    gdn = None
    if layer.gdn is not None:
        g = layer.gdn
        kd, vd = cfg.k_heads * cfg.dk, cfg.v_heads * cfg.dv
        rows = output_rows(g.qkv.n, rank, segments=(kd, kd, vd), device=g.conv.device)
        vh = cfg.v_heads // world_size
        lo, hi = rank * vh, (rank + 1) * vh
        gdn = GDN(qkv=split_output(g.qkv, rank, segments=(kd, kd, vd)),
                  z=split_output(g.z, rank, block=cfg.dv),
                  b=split_output(g.b, rank), a=split_output(g.a, rank),
                  out=split_input(g.out, rank),
                  conv=g.conv.index_select(0, rows).contiguous(),
                  A_log=g.A_log[lo:hi].contiguous(),
                  dt_bias=g.dt_bias[lo:hi].contiguous(), norm=g.norm)
    local = Layer(linear=layer.linear, input_norm=layer.input_norm, post_norm=layer.post_norm,
                  gdn=gdn, attn=attn, gate=split_output(layer.gate, rank),
                  up=split_output(layer.up, rank), down=split_input(layer.down, rank))
    return LayerShard(local, rank, world_size, cfg.heads // world_size, cfg.kv_heads // world_size,
                      cfg.k_heads // world_size, cfg.v_heads // world_size)


def split_weights(w: Weights, rank: int, world_size: int = 2, *, tiled: bool = False,
                  fuse: bool = False, split_head: bool = False) -> Weights:
    """Shard stored MLX words before optional bit-preserving tiling, optionally splitting head rows whose full dot products preserve logits and merged-candidate sampling."""

    _rank(rank, world_size)
    c = w.config
    local_cfg = replace(c, heads=c.heads // world_size, kv_heads=c.kv_heads // world_size,
                        k_heads=c.k_heads // world_size, v_heads=c.v_heads // world_size,
                        intermediate=c.intermediate // world_size)
    layers = []
    for layer in w.layers:
        local = split_layer(layer, c, rank, world_size).layer
        if tiled:
            from .qmm_fast import stack_small, tile

            if fuse:
                stack_small(local)
            for owner, names in ((local, ("gate", "up", "down")), (local.gdn, ("qkv", "z", "b", "a", "out", "zba")),
                                 (local.attn, ("q", "k", "v", "o", "kv"))):
                if owner is not None:
                    for name in names:
                        if getattr(owner, name) is not None:
                            setattr(owner, name, tile(getattr(owner, name)))
        layers.append(local)
    head = split_output(w.head, rank, world_size) if split_head else w.head
    if tiled:
        from .qmm_fast import tile

        head = tile(head)
    return Weights(local_cfg, w.embed, layers, w.norm, head, w.inv_freq)


if triton is not None:
    @triton.jit
    def _row_qmm(X, XS, W, S, B, OUT, PART, M,
                 N: tl.constexpr, K: tl.constexpr, SK: tl.constexpr,
                 BM: tl.constexpr, BLOCK_N: tl.constexpr):
        KG: tl.constexpr = K // 64
        PER: tl.constexpr = KG // SK
        K8: tl.constexpr = K // 8
        pid_n = tl.program_id(0)
        pid_s = tl.program_id(1)
        rm = tl.arange(0, BM)
        rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
        rk = tl.arange(0, 64)
        rw = tl.arange(0, 8)
        shifts = tl.arange(0, 8) * 4
        m_ok = rm < M
        n_ok = rn < N
        acc = tl.zeros((BM, BLOCK_N), dtype=tl.float32)
        for i in range(PER):
            g = pid_s * PER + i
            x = tl.load(X + rm[:, None] * K + (g * 64 + rk)[None, :], mask=m_ok[:, None], other=0.0)
            words = tl.load(W + rn[:, None] * K8 + (g * 8 + rw)[None, :], mask=n_ok[:, None], other=0)
            q = (words[:, :, None] >> shifts[None, None, :]) & 0xF
            q = tl.reshape(q, (BLOCK_N, 64)).to(tl.bfloat16)
            p = tl.dot(x, tl.trans(q))
            s = tl.load(S + rn * KG + g, mask=n_ok, other=0.0).to(tl.float32)
            b = tl.load(B + rn * KG + g, mask=n_ok, other=0.0).to(tl.float32)
            xs = tl.load(XS + rm * KG + g, mask=m_ok, other=0.0)
            acc = acc + p * s[None, :] + xs[:, None] * b[None, :]
        mask = m_ok[:, None] & n_ok[None, :]
        if SK == 1:
            tl.store(OUT + rm[:, None] * N + rn[None, :], acc, mask=mask)
        else:
            tl.store(PART + (pid_s * M + rm[:, None]) * N + rn[None, :], acc, mask=mask)


    @triton.jit
    def _reduce_slices(PART, OUT, total, SK: tl.constexpr, BLOCK: tl.constexpr):
        offs = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        ok = offs < total
        acc = tl.load(PART + offs, mask=ok, other=0.0)
        for s in tl.static_range(1, SK):
            acc = acc + tl.load(PART + s * total + offs, mask=ok, other=0.0)
        tl.store(OUT + offs, acc, mask=ok)


def row_partial(x: torch.Tensor, q: QLinear, sk: int | None = None,
                xs: torch.Tensor | None = None) -> torch.Tensor:
    """Row-parallel projection, returning an fp32 (rows, outputs) partial."""

    if not q.fast:
        from tensorfold.cuda.kernels.affine import matmul as affine_matmul

        return affine_matmul(x, q, f32=True)
    if triton is None:
        raise RuntimeError("row_partial requires Triton")
    if q.layout == "tiled":
        from .qmm_fast import matmul_partial

        if sk is not None:
            raise ValueError("tiled row partials use the shape's own split")
        return matmul_partial(x, q, xs)
    if x.ndim != 2 or x.dtype != torch.bfloat16 or x.shape[1] != q.k or q.k % 64:
        raise ValueError("row_partial expects (rows, shard K) bf16 and group-aligned weights")
    if q.weight.dtype != torch.int32 or q.scales.shape != (q.n, q.k // 64) or q.biases.shape != q.scales.shape:
        raise ValueError("row_partial expects packed int32 words and matching group metadata")
    if not x.is_cuda or any(t.device != x.device for t in (q.weight, q.scales, q.biases)):
        raise ValueError("row_partial requires all tensors on the same CUDA device")
    from .qmm import BN, bucket, group_sums, split_k

    m = x.shape[0]
    if m > 128:
        raise ValueError("the stored-layout row partial takes at most 128 rows (one row tile)")
    bm = bucket(m)
    x = x.contiguous()
    xs = group_sums(x)
    sk = split_k(q.n, q.k) if sk is None else int(sk)
    if sk < 1 or sk > 8 or (q.k // 64) % sk:
        raise ValueError("split K must divide the number of 64-input groups")
    out = torch.empty((m, q.n), dtype=torch.float32, device=x.device)
    part = out if sk == 1 else torch.empty((sk, m, q.n), dtype=torch.float32, device=x.device)
    _row_qmm[(triton.cdiv(q.n, BN), sk)](
        x, xs, q.weight, q.scales, q.biases, out, part, m,
        N=q.n, K=q.k, SK=sk, BM=bm, BLOCK_N=BN,
        num_warps=4 if bm <= 32 else 8, num_stages=3)
    if sk > 1:
        total = m * q.n
        _reduce_slices[(triton.cdiv(total, 1024),)](part, out, total, SK=sk, BLOCK=1024, num_warps=4)
    return out


def sum_rank_partials(partials: Sequence[torch.Tensor], dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
    """Local rank-ordered sum, useful for one-GPU parity tests."""

    if len(partials) != 2 or any(p.dtype != torch.float32 or p.shape != partials[0].shape for p in partials):
        raise ValueError("expected two equally shaped fp32 partials in rank order")
    return (partials[0] + partials[1]).to(dtype)


def gather_rank_partials(local: torch.Tensor, group=None,
                         dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
    """Add two ranks' partials rank 0 first in fp32 and round once; an NCCL all-reduce leaves the order to NCCL."""

    if not dist.is_initialized() or dist.get_world_size(group) != 2:
        raise RuntimeError("a two-rank process group must be initialized")
    if local.dtype not in (torch.float32, torch.bfloat16) or local.ndim != 2:
        raise ValueError("local partial must be a 2-D fp32 or bf16 tensor")
    if dist.get_backend(group) == "nccl" and not local.is_cuda:
        raise ValueError("NCCL partial must be on CUDA")
    local = local.contiguous()
    if os.environ.get("TF_TP_REDUCE") == "allreduce":
        dist.all_reduce(local, op=dist.ReduceOp.SUM, group=group)
        return local.to(dtype)
    gathered = torch.empty((2 * local.shape[0], local.shape[1]), dtype=local.dtype, device=local.device)
    dist.all_gather_into_tensor(gathered, local, group=group)
    rank_parts = gathered.view(2, *local.shape)
    return (rank_parts[0].float() + rank_parts[1].float()).to(dtype)
