"""Prepare or execute six sequential CPU weight exports, TF351 first.

This tool cannot start/stop an engine, touch GPUs, or switch production. It
requires fresh output paths and completed pinned source verification receipts.
Dry-run is the default. Failed/incomplete output is retained, never cleaned up.
"""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from source_verify import safe_path,check_receipt
from io_budget import Budget
from vision_export import selected,prepare_models

ARMS=('TF351','TF29')
RESERVE=10<<30


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def exclusive_json(path,data):
    with path.open('x') as f:
        json.dump(data,f,indent=2);f.flush();os.fsync(f.fileno())


def prepare(prep,kit,out,rate):
    Budget(rate)
    info=json.loads((prep/'PREPARATION.json').read_bytes())
    for name,expected in info['files'].items():
        path=safe_path(prep,name)
        if path.stat().st_size!=expected['size'] or sha(path)!=expected['sha256']:
            raise ValueError('Preparation input changed: '+name)
    roots={'pollard':Path(info['production_readonly_source']),'mia':Path(info['mia_source'])}
    sources_ready=True;missing=[];receipts={}
    for source in roots:
        path=prep/(source+'-receipt.json')
        if not path.exists():sources_ready=False;missing.append(str(path));continue
        receipt=json.loads(path.read_bytes())
        mf=prep/(source+'-upstream-manifest.json')
        if receipt.get('manifest_sha256')!=sha(mf):raise ValueError('Source manifest receipt differs')
        receipts[source]=receipt
    tools=Path(__file__).resolve().parent;steps=[]
    for arm in ARMS:
        plan_path=prep/(arm+'.json');plan=json.loads(plan_path.read_bytes())
        metadata=kit/'models'/arm/'config.json'
        cfg=json.loads(metadata.read_bytes())
        if (cfg.get('tensorfold_tp3',{}).get('arm')!=arm or
                cfg['tensorfold_tp3'].get('weight_plan_sha256')!=sha(plan_path)):
            raise ValueError('Serving metadata does not match plan: '+arm)
        vision=selected(plan)
        vision_bytes=sum(t['bytes'] for t in vision.values())
        needed={}
        for t in plan['tensors'].values():needed.setdefault(t['source'],set()).add(t['shard'])
        for source,shards in needed.items():
            if source in receipts:check_receipt(receipts[source],roots[source],plan['sources'][source],shards)
        # Parent must not retain the large parsed checkpoint beside export child.
        del plan,vision;gc.collect()
        for rank in range(3):
            keys=prep/f'rank{rank}.keys'
            name=f'rank{rank}of3-{arm}-{sha(plan_path)[:20]}.bin'
            target=out/arm/name
            base=[sys.executable,str(tools/'rank_cache.py'),'--plan',str(plan_path),
                  '--keys',str(keys),'--pollard',str(roots['pollard']),'--mia',str(roots['mia']),
                  '--out',str(target),'--read-mib-s',str(rate)]
            dry=json.loads(subprocess.check_output(base,text=True))
            source_args=[]
            for source in roots:source_args+=['--source-receipt',source+'='+str(prep/(source+'-receipt.json'))]
            verify=[sys.executable,str(tools/'rank_verify.py'),'--plan',str(plan_path),
                    '--keys',str(keys),'--pollard',str(roots['pollard']),'--mia',str(roots['mia']),
                    '--artifact',str(target),'--out',str(target.with_suffix('.verified.json')),
                    '--read-mib-s',str(rate),'--full-hash']+source_args
            steps.append(dict(arm=arm,rank=rank,target=str(target),expected=dry,
                              export_argv=base+source_args+['--write'],verify_argv=verify))
    code={p.name:sha(p) for p in [tools/x for x in ('export_campaign.py','rank_cache.py',
        'rank_verify.py','source_verify.py','io_budget.py','materialize_checkpoint.py','tp3_layout.py','vision_export.py')]}
    return dict(schema='ds41f.cpu-export-campaign.v1',sources_ready=sources_ready,
                missing_receipts=missing,tools_sha256=code,steps=steps,
                payload_bytes=sum(s['expected']['payload_bytes'] for s in steps),
                free_space_reserve_bytes=RESERVE,vision_payload_bytes=vision_bytes,
                preparation=str(prep),serving_kit=str(kit),read_mib_s=rate,gpu_used=False)


def execute(plan,out):
    if not plan['sources_ready']:raise ValueError('Source verification receipts are still missing')
    if out.exists():raise FileExistsError(out)
    remaining=plan['payload_bytes']+plan['vision_payload_bytes']
    if shutil.disk_usage(out.parent).free<remaining+RESERVE:raise ValueError('Insufficient disk space')
    out.mkdir()
    exclusive_json(out/'CAMPAIGN.json',plan)
    print('START shared vision',flush=True)
    vision=prepare_models(Path(plan['preparation']),Path(plan['serving_kit']),out,read_mib_s=plan['read_mib_s'])
    if vision['payload_bytes']!=plan['vision_payload_bytes']:raise ValueError('Vision byte total differs')
    remaining-=vision['payload_bytes']
    print('CPU BITWISE VERIFIED shared vision',flush=True)
    for step in plan['steps']:
        target=Path(step['target']);target.parent.mkdir(exist_ok=True)
        if shutil.disk_usage(out).free<remaining+RESERVE:raise ValueError('Disk space changed before export')
        label=step['arm']+'-rank'+str(step['rank'])
        print('START '+label,flush=True)
        for kind in ('export','verify'):
            with (out/(label+'-'+kind+'.log')).open('xb') as log:
                r=subprocess.run(step[kind+'_argv'],stdout=log,stderr=subprocess.STDOUT,
                                 env=dict(os.environ,CUDA_VISIBLE_DEVICES=''))
            if r.returncode:
                exclusive_json(out/'FAILED.json',dict(arm=step['arm'],rank=step['rank'],
                    stage=kind,returncode=r.returncode,status='INCOMPLETE_RETAINED'))
                raise RuntimeError(label+' '+kind+' failed; inspect retained log')
        result=json.loads(target.with_suffix('.verified.json').read_bytes())
        if (result['status']!='CPU_CHECKED_NOT_GPU_QUALIFIED' or not result['full_sha256_checked']
                or result['payload_bytes']!=step['expected']['payload_bytes']
                or result['entries']!=step['expected']['entries']):
            raise ValueError('Export verification result differs: '+label)
        remaining-=step['expected']['payload_bytes']
        print('CPU VERIFIED '+label,flush=True)
    exclusive_json(out/'COMPLETE.json',dict(status='CPU_EXPORTS_COMPLETE_NOT_GPU_QUALIFIED',
                                          arms=list(ARMS),ranks=3,gpu_used=False))


def main():
    p=argparse.ArgumentParser()
    for name in ('preparation','serving-kit','out'):p.add_argument('--'+name,required=True)
    p.add_argument('--read-mib-s',type=float,default=128)
    p.add_argument('--plan-out')
    p.add_argument('--write',action='store_true')
    a=p.parse_args();out=Path(a.out).resolve()
    plan=prepare(Path(a.preparation).resolve(),Path(a.serving_kit).resolve(),out,a.read_mib_s)
    if a.plan_out:exclusive_json(Path(a.plan_out),plan)
    if a.write:execute(plan,out)
    else:print(json.dumps(plan,indent=2))


if __name__=='__main__':main()
