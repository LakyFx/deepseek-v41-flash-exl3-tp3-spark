"""Keep the native vision tower functional beside direct rank-cache exports."""
import hashlib
import json
import os
from pathlib import Path
import shutil
from io_budget import Budget,Reader
from materialize_checkpoint import write_shard,read_header
from source_verify import check_receipt

TAIL=('vision.patch_embed.proj.weight','vision.patch_embed.proj.bias','vision.norm.weight',
      'aligner.w1.weight','aligner.w1.bias','aligner.w2.weight','aligner.w2.bias',
      'image_start','image_newline','image_end')
BLOCK=('attn.wqkv.weight','attn.wqkv.bias','attn.wo.weight','attn.wo.bias',
       'norm1.weight','norm2.weight','mlp.w1.weight','mlp.w2.weight')


def selected(plan):
    wanted={f'vision.blocks.{i}.{n}' for i in range(32) for n in BLOCK}|set(TAIL)
    items={k:t for k,t in plan['tensors'].items()
           if k.startswith(('vision.','aligner.','image_'))}
    if set(items)!=wanted:raise ValueError('Native vision tensor coverage differs')
    if any(x['source']!='mia' or x['dtype']!='BF16' for x in items.values()):
        raise ValueError('Vision requires the original Mia BF16 tensors')
    if len({x['shard'] for x in items.values()})!=1:raise ValueError('Unexpected vision source split')
    return items


def compare_payload(source,target,items,*,read_mib_s=0):
    """Compare every selected byte, not just representative scalar probes."""
    budget=Budget(read_mib_s);total=0
    with Reader(source.open('rb'),budget) as src,Reader(target.open('rb'),budget) as dst:
        sh,sbase=read_header(src);dh,dbase=read_header(dst)
        if set(dh)!=set(items):raise ValueError('Vision output tensor set differs')
        for name,spec in items.items():
            if sh[name]!={k:spec[k] for k in ('dtype','shape','data_offsets')}:
                raise ValueError('Vision source header changed')
            if dh[name]['dtype']!=spec['dtype'] or dh[name]['shape']!=spec['shape']:
                raise ValueError('Vision output layout differs')
            if dh[name]['data_offsets'][1]-dh[name]['data_offsets'][0]!=spec['bytes']:
                raise ValueError('Vision output length differs')
            src.seek(sbase+spec['data_offsets'][0]);dst.seek(dbase+dh[name]['data_offsets'][0])
            remaining=spec['bytes']
            while remaining:
                n=min(4<<20,remaining);a=src.read(n);b=dst.read(n)
                if len(a)!=n or a!=b:raise ValueError('Vision payload differs: '+name)
                remaining-=n;total+=n
    return total


def prepare_models(prep,kit,out,*,read_mib_s=128):
    first=json.loads((prep/'TF351.json').read_bytes());items=selected(first)
    second=json.loads((prep/'TF29.json').read_bytes())
    if items!=selected(second):raise ValueError('Arms disagree on shared vision tensors')
    source_pin=first['sources']['mia']
    del first,second
    receipt=json.loads((prep/'mia-receipt.json').read_bytes())
    info=json.loads((prep/'PREPARATION.json').read_bytes());source_root=Path(info['mia_source'])
    shard=next(iter(items.values()))['shard']
    check_receipt(receipt,source_root,source_pin,{shard})
    folder=out/'vision';folder.mkdir()
    target=folder/'vision.safetensors';source=source_root/shard
    header,payload=write_shard(source,target,items,read_mib_s=read_mib_s)
    compared=compare_payload(source,target,items,read_mib_s=read_mib_s)
    check_receipt(receipt,source_root,source_pin,{shard})
    digest=hashlib.sha256()
    with Reader(target.open('rb'),Budget(read_mib_s)) as f:
        while data:=f.read(8<<20):digest.update(data)
    result=dict(status='CPU_BITWISE_VERIFIED_NOT_GPU_QUALIFIED',entries=len(items),
                payload_bytes=payload,compared_bytes=compared,artifact_sha256=digest.hexdigest(),
                artifact_bytes=target.stat().st_size,source=source_pin,source_shard=shard,gpu_used=False)
    with (folder/'receipt.json').open('x') as f:json.dump(result,f,indent=2)
    for arm in ('TF351','TF29'):
        model=out/'models'/arm;model.mkdir(parents=True)
        for name in ('config.json','tokenizer.json','tokenizer_config.json'):
            shutil.copyfile(kit/'models'/arm/name,model/name)
        os.link(target,model/'vision.safetensors')
        with (model/'model.safetensors.index.json').open('x') as f:
            json.dump({'metadata':{'total_size':payload},
                       'weight_map':{name:'vision.safetensors' for name in header}},f)
    return result
