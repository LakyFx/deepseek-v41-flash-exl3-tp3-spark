"""Build immutable tensor provenance plans; does not load GPU or alter weights.

TF351 retains all 40 target layers' routed expert bundles from Pollard.
All other tensors, including DSpark, are from Mia, matching the fork's EXL3
layout. TF29 is the complete Mia checkpoint. Plans are pre-padding inputs,
NOT a claim that upstream TensorFold can serve TP3 yet.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROUTED = re.compile(r"layers\.(\d+)\.ffn\.experts\.(\d+)\.(w[123])\.(trellis|suh|svh|mul1)$")
PARTS = {"trellis", "suh", "svh", "mul1"}


def read_headers(path):
    raw = Path(path).read_bytes()
    doc = json.loads(raw)
    if doc.get("errors"):
        raise ValueError("Header collection has errors")
    tensors = {}
    for shard, header in doc["headers"].items():
        for name, spec in header.items():
            if name == "__metadata__":
                continue
            if name in tensors:
                raise ValueError("Duplicate tensor: " + name)
            lo, hi = spec["data_offsets"]
            if lo < 0 or hi < lo:
                raise ValueError("Invalid offsets: " + name)
            tensors[name] = dict(spec, shard=shard, bytes=hi - lo)
    return doc, tensors, hashlib.sha256(raw).hexdigest()


def select(base, mia, hybrid):
    result = {}
    bundles = {}
    for name, donor in mia.items():
        match = ROUTED.fullmatch(name)
        use_base = hybrid and match is not None
        selected = base.get(name) if use_base else donor
        if selected is None:
            raise ValueError("Missing original expert: " + name)
        if use_base:
            layer, expert = int(match[1]), int(match[2])
            if not (0 <= layer < 40 and 0 <= expert < 384):
                raise ValueError("Unexpected routed expert: " + name)
            # Trellis last axis encodes bit width, so only its K/N tile axes
            # must match. All scale shapes and marker dtypes must agree.
            shape = selected["shape"]
            wanted = donor["shape"]
            same = shape[:2] == wanted[:2] if match[4] == "trellis" else shape == wanted
            if not same or selected["dtype"] != donor["dtype"]:
                raise ValueError("Incompatible tensor geometry: " + name)
            bundles.setdefault(name.rsplit('.', 1)[0], set()).add(match[4])
        result[name] = dict(selected, source="pollard" if use_base else "mia")
    if hybrid:
        if len(bundles) != 40 * 384 * 3 or any(p != PARTS for p in bundles.values()):
            raise ValueError("Incomplete target expert bundles")
        base_routed = {k for k in base if ROUTED.fullmatch(k)}
        chosen = {k for k, v in result.items() if v["source"] == "pollard"}
        if base_routed != chosen:
            raise ValueError("Unaccounted original routed expert tensors")
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--pollard-headers", required=True)
    p.add_argument("--mia-headers", required=True)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    bd, base, bh = read_headers(a.pollard_headers)
    md, mia, mh = read_headers(a.mia_headers)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    summary = {}
    for arm, hybrid in [("TF351", True), ("TF29", False)]:
        tensors = select(base, mia, hybrid)
        counts = {s: sum(v["bytes"] for v in tensors.values() if v["source"] == s)
                  for s in ["pollard", "mia"]}
        doc = {"schema": "ds41f.tensorfold.checkpoint-plan.v1", "arm": arm,
               "stage": "PRE_PADDING_SOURCE_SELECTION", "serving_ready": False,
               "sources": {"pollard": {"repo": bd["repo"], "revision": bd["revision"], "headers_sha256": bh},
                           "mia": {"repo": md["repo"], "revision": md["revision"], "headers_sha256": mh}},
               "stored_bytes_by_source": counts, "tensors": tensors}
        target = out / (arm + '.json')
        target.write_text(json.dumps(doc, separators=(',', ':')), encoding='utf-8')
        summary[arm] = {"tensor_count": len(tensors), "stored_bytes_by_source": counts,
                        "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
    (out / 'SUMMARY.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
