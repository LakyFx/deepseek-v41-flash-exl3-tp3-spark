//! The prompt cache's tests: a fake family whose state is a running sum, so a resumed pass equals a fresh one exactly when it should.
const std = @import("std");
const pc = @import("prompt_cache.zig");
const imprint = @import("prompt_imprint.zig");
const rmTree = @import("prompt_imprint_test.zig").rmTree;
const Snapshots = pc.Snapshots;
const Saved = pc.Saved;
const Store = pc.Store;
const Plan = pc.Plan;
const Allocator = std.mem.Allocator;

/// Rank 1's bytes: it applies a request's drops before that request's keeps; drops made during a pass wait for the next request.
const Peer = struct {
    held: u64 = 0,
    pending: u64 = 0,
    max: u64 = 0,
    in_pass: bool = false,

    fn request(p: *Peer) void {
        p.held -= p.pending;
        p.pending = 0;
    }
};

/// A family over host memory for tests: its live state is a position and a running sum of the prompt's tokens.
const Fake = struct {
    gpa: Allocator,
    at: u32 = 0,
    sum: u64 = 0,
    fail_save: bool = false,
    fail_restore: bool = false,
    live: usize = 0,
    spare_bytes: u64 = 0,
    peer: ?*Peer = null, // speed-up mode's rank 1: it keeps the same states and drops them only when a request names them

    const State = struct { at: u32, sum: u64 };

    fn snapshots(f: *Fake) Snapshots {
        return .{ .ptr = f, .vtable = &.{ .bytes = bytesFn, .save = saveFn, .restore = restoreFn, .drop = dropFn } };
    }
    /// With learned states on disk: a state's position and sum in one file.
    fn learned(f: *Fake) Snapshots {
        return .{ .ptr = f, .vtable = &.{ .bytes = bytesFn, .save = saveFn, .restore = restoreFn, .drop = dropFn, .write = writeFn, .read = readFn, .forget = forgetFn } };
    }
    fn forgetFn(_: *anyopaque, dir: [:0]const u8, key: u64) void {
        var path: [512]u8 = undefined;
        _ = std.c.unlink(file(&path, dir, key) catch return);
    }
    fn file(buf: []u8, dir: []const u8, key: u64) ![:0]const u8 {
        return std.fmt.bufPrintSentinel(buf, "{s}/{x:0>16}.bin", .{ dir, key }, 0);
    }
    fn writeFn(_: *anyopaque, saved: Saved, dir: [:0]const u8, key: u64) anyerror!void {
        var path: [512]u8 = undefined;
        const fd = std.c.open(try file(&path, dir, key), .{ .ACCMODE = .WRONLY, .CREAT = true, .TRUNC = true }, @as(std.c.mode_t, 0o600));
        if (fd < 0) return error.WriteFailed;
        defer _ = std.c.close(fd);
        try imprint.writeAll(fd, std.mem.asBytes(@as(*State, @ptrCast(@alignCast(saved)))));
    }
    fn readFn(ptr: *anyopaque, dir: [:0]const u8, key: u64, at: u32) anyerror!Saved {
        const f = of(ptr);
        var path: [512]u8 = undefined;
        const fd = std.c.open(try file(&path, dir, key), .{ .ACCMODE = .RDONLY }, @as(std.c.mode_t, 0));
        if (fd < 0) return error.ReadFailed;
        defer _ = std.c.close(fd);
        const st = try f.gpa.create(State);
        errdefer f.gpa.destroy(st);
        if (!imprint.readAt(fd, std.mem.asBytes(st), 0) or st.at != at) return error.ReadFailed;
        f.live += 1;
        return st;
    }
    /// A pool-like family: a kept state holds 10 bytes under `bytes`, and a dropped one's storage stays spare.
    fn pooled(f: *Fake) Snapshots {
        return .{ .ptr = f, .vtable = &.{ .bytes = bytesFn, .save = savePooledFn, .restore = restoreFn, .drop = dropSpareFn, .charged = chargedFn, .spare = spareFn, .trim = trimFn, .reuses = reusesFn } };
    }
    fn reusesFn(ptr: *anyopaque, at: u32) bool {
        return of(ptr).spare_bytes >= 90 + at;
    }
    fn savePooledFn(ptr: *anyopaque, owner: ?*anyopaque, at: u32) anyerror!Saved {
        const st = try saveFn(ptr, owner, at);
        const f = of(ptr);
        if (f.spare_bytes >= 90 + at) f.spare_bytes -= 90 + at; // the spare storage took it
        return st;
    }
    fn chargedFn(_: *anyopaque, saved: Saved) u64 {
        const st: *State = @ptrCast(@alignCast(saved));
        return 90 + st.at;
    }
    fn dropSpareFn(ptr: *anyopaque, saved: Saved) void {
        const st: *State = @ptrCast(@alignCast(saved));
        of(ptr).spare_bytes += 90 + st.at;
        dropFn(ptr, saved);
    }
    fn spareFn(ptr: *anyopaque) u64 {
        return of(ptr).spare_bytes;
    }
    fn trimFn(ptr: *anyopaque, room_: u64) void {
        const f = of(ptr);
        f.spare_bytes = @min(f.spare_bytes, room_);
    }
    fn of(ptr: *anyopaque) *Fake {
        return @ptrCast(@alignCast(ptr));
    }
    fn bytesFn(_: *anyopaque, at: u32) u64 {
        return 100 + at;
    }
    fn saveFn(ptr: *anyopaque, _: ?*anyopaque, at: u32) anyerror!Saved {
        const f = of(ptr);
        if (f.fail_save) return error.CopyFailed;
        if (at != f.at) return error.NotAtMark;
        const st = try f.gpa.create(State);
        st.* = .{ .at = f.at, .sum = f.sum };
        f.live += 1;
        if (f.peer) |p| {
            p.held += 100 + at;
            p.max = @max(p.max, p.held);
        }
        return st;
    }
    fn restoreFn(ptr: *anyopaque, _: ?*anyopaque, saved: Saved) anyerror!void {
        const f = of(ptr);
        if (f.fail_restore) return error.CopyFailed;
        const st: *State = @ptrCast(@alignCast(saved));
        f.at, f.sum = .{ st.at, st.sum };
    }
    fn dropFn(ptr: *anyopaque, saved: Saved) void {
        const f = of(ptr);
        const st: *State = @ptrCast(@alignCast(saved));
        if (f.peer) |p| { // dropped before the pass: named in this request; during it: in the next one
            if (p.in_pass) p.pending += 100 + st.at else p.held -= 100 + st.at;
        }
        f.gpa.destroy(st);
        f.live -= 1;
    }

    /// A prompt pass from `plan.from`, keeping at each mark; returns the sum a fresh pass would give.
    fn pass(f: *Fake, s: *Store, prompt: []const u32, plan: Plan) u64 {
        if (plan.from == 0) f.* = .{ .gpa = f.gpa, .fail_save = f.fail_save, .fail_restore = f.fail_restore, .live = f.live, .spare_bytes = f.spare_bytes, .peer = f.peer };
        if (f.peer) |p| p.in_pass = true;
        defer if (f.peer) |p| {
            p.in_pass = false;
        };
        var mi: usize = 0;
        for (prompt[plan.from..]) |t| {
            f.sum = f.sum *% 31 +% t;
            f.at += 1;
            if (mi < plan.marks.len and plan.marks[mi] == f.at) {
                _ = s.keep(prompt, f.at, null, &.{});
                mi += 1;
            }
        }
        return f.sum;
    }
};

fn fresh(prompt: []const u32) u64 {
    var sum: u64 = 0;
    for (prompt) |t| sum = sum *% 31 +% t;
    return sum;
}

test "salted prefixes and shared cuts stay in their own namespaces" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .lookahead = 1, .min_prompt = 0, .min_gap = 1 }, 1 << 20);
    defer s.deinit();
    const prompt = [_]u32{ 1, 2, 3, 4, 5, 6 };
    const namespaces = [_]pc.Namespace{ pc.namespaceFor("A"), pc.namespaceFor("B"), null };
    for (namespaces, 0..) |ns, i| {
        const plan = try s.lookupScoped(ns, arena.allocator(), &prompt, 4, if (i == 0) &.{2} else &.{}, &.{});
        try std.testing.expect(plan.entry == null);
        f.at = 2;
        f.sum = fresh(prompt[0..2]);
        try std.testing.expect(s.keepScoped(ns, &prompt, 2, null, &.{}));
        const entry = s.findScoped(ns, &prompt, &.{}).?;
        try std.testing.expectEqual(i == 0, entry.shared);
        try std.testing.expectEqual(@as(usize, i + 1), s.entries.items.len);
        // Saving again deduplicates only within this same namespace.
        try std.testing.expect(s.keepScoped(ns, &prompt, 2, null, &.{}));
        try std.testing.expectEqual(@as(usize, i + 1), s.entries.items.len);
        const hot = try s.lookupScoped(ns, arena.allocator(), &prompt, 4, &.{}, &.{});
        try std.testing.expect(hot.entry == entry);
        try std.testing.expect(s.findScoped(ns, &.{ 1, 2, 99, 4, 5, 6 }, &.{}) == null);
    }
    try std.testing.expect(s.findScoped(namespaces[0], &prompt, &.{}) != s.findScoped(namespaces[1], &prompt, &.{}));
    // Existing unsalted invalidation cannot drop a salted entry.
    s.forget(&prompt, 2);
    try std.testing.expect(s.find(&prompt, &.{}) == null);
    try std.testing.expect(s.findScoped(namespaces[0], &prompt, &.{}) != null);
    try s.clear();
    try std.testing.expectEqual(@as(usize, 0), f.live);
    for (namespaces) |ns| try std.testing.expect(s.findScoped(ns, &prompt, &.{}) == null);
}

test "a different namespace extending identical tokens does not supersede that conversation" {
    const gpa = std.testing.allocator;
    var f: Fake = .{ .gpa = gpa, .at = 3 };
    var s = Store.init(gpa, f.snapshots(), .{ .min_prompt = 0 }, 208);
    defer s.deinit();
    const a = pc.namespaceFor("A");
    const b = pc.namespaceFor("B");
    const c = pc.namespaceFor("C");
    const old = [_]u32{ 7, 8, 9, 0 };
    const newer = [_]u32{ 1, 2, 3, 0 };
    const extended = [_]u32{ 1, 2, 3, 0, 4, 5 };
    try std.testing.expect(s.keepScoped(b, &old, 3, null, &.{}));
    try std.testing.expect(s.keepScoped(a, &newer, 3, null, &.{}));
    try std.testing.expect(s.keepScoped(c, &extended, 3, null, &.{}));
    try std.testing.expect(s.findScoped(b, &old, &.{}) == null); // oldest, not A's unrelated conversation
    try std.testing.expect(s.findScoped(a, &newer, &.{}) != null);
    try std.testing.expect(s.findScoped(c, &extended, &.{}) != null);
}

test "a growing conversation resumes each turn where the last one's history ended, and equals a fresh pass" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .lookahead = 1, .min_prompt = 0 }, 1 << 20);
    defer s.deinit();
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 9, 9 }; // history 5, then a two-token generation prompt
    var p = try s.begin(a, &t1, 5, &.{}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 0), p.from);
    try std.testing.expectEqualSlices(u32, &.{5}, p.marks);
    try std.testing.expectEqual(fresh(&t1), f.pass(&s, &t1, p));
    const t2 = [_]u32{ 1, 2, 3, 4, 5, 9, 7, 7, 6, 6, 9, 9 }; // the reply and a tool result, history 10
    p = try s.begin(a, &t2, 10, &.{}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 5), p.from);
    try std.testing.expectEqualSlices(u32, &.{10}, p.marks);
    try std.testing.expectEqual(fresh(&t2), f.pass(&s, &t2, p));
    const edited = [_]u32{ 1, 2, 3, 8, 5, 9, 7, 7, 6, 6, 9, 9 }; // an earlier turn edited: nothing resumes past it
    p = try s.begin(a, &edited, 10, &.{}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 0), p.from);
    try std.testing.expectEqual(fresh(&edited), f.pass(&s, &edited, p));
    try std.testing.expectEqual(@as(u64, 1), s.counts.hits);
    try std.testing.expectEqual(@as(u64, 2), s.counts.misses);
}

test "an entry keys its lookahead tokens: a prompt that differs right after the state does not resume it" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .lookahead = 1, .min_prompt = 0 }, 1 << 20);
    defer s.deinit();
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 9 };
    _ = f.pass(&s, &t1, try s.begin(a, &t1, 4, &.{}, &.{}, null)); // keeps [1 2 3 4] + 5
    try std.testing.expect(s.find(&.{ 1, 2, 3, 4, 6, 9 }, &.{}) == null);
    try std.testing.expectEqual(@as(u32, 4), s.find(&.{ 1, 2, 3, 4, 5, 6 }, &.{}).?.at);
    try std.testing.expect(s.find(&.{ 1, 2, 3, 4 }, &.{}) == null); // the lookahead token must be in the prompt
}

test "planned families resume and keep only at the request's chunk starts" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .planned = true, .min_prompt = 0 }, 1 << 20);
    defer s.deinit();
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 6, 7, 8 };
    const p = try s.begin(a, &t1, 7, &.{}, &.{ 4, 6 }, null);
    try std.testing.expectEqualSlices(u32, &.{6}, p.marks); // history 7 floored to the start at 6
    _ = f.pass(&s, &t1, p);
    try std.testing.expect(s.find(&.{ 1, 2, 3, 4, 5, 6, 7, 9 }, &.{4}) == null); // 6 is not one of this prompt's starts
    try std.testing.expectEqual(@as(u32, 6), s.find(&.{ 1, 2, 3, 4, 5, 6, 7, 9 }, &.{ 4, 6 }).?.at);
}

test "eviction frees a conversation's superseded state first, then the oldest; a state past the budget is refused" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .min_prompt = 0 }, 330); // fake bytes: 100 + at
    defer s.deinit();
    const other = [_]u32{ 5, 5, 5, 5 };
    _ = f.pass(&s, &other, try s.begin(a, &other, 3, &.{}, &.{}, null)); // 103 bytes
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 6 };
    _ = f.pass(&s, &t1, try s.begin(a, &t1, 4, &.{}, &.{}, null)); // 104: 207 held
    const t2 = [_]u32{ 1, 2, 3, 4, 5, 6, 7, 8 };
    _ = f.pass(&s, &t2, try s.begin(a, &t2, 6, &.{}, &.{}, null)); // 106 more: 313
    try std.testing.expectEqual(@as(usize, 3), s.entries.items.len);
    const t3 = [_]u32{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    _ = f.pass(&s, &t3, try s.begin(a, &t3, 8, &.{}, &.{}, null)); // 108: t1's state (extended by later turns) goes first
    try std.testing.expectEqual(@as(usize, 3), s.entries.items.len);
    try std.testing.expect(s.find(&.{ 5, 5, 5, 5 }, &.{}) != null);
    try std.testing.expectEqual(@as(u32, 8), s.find(&t3, &.{}).?.at);
    const big: [300]u32 = @splat(7);
    _ = f.pass(&s, &big, try s.begin(a, &big, 299, &.{}, &.{}, null)); // 399 > 330: refused, nothing evicted
    try std.testing.expectEqual(@as(u64, 1), s.counts.refused);
    try std.testing.expectEqual(@as(usize, 3), s.entries.items.len);
    try std.testing.expect(s.held <= s.budget);
    try std.testing.expectEqual(s.entries.items.len, f.live);
}

test "a failed copy keeps nothing and a failed restore prefills from the start" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa, .fail_save = true };
    var s = Store.init(gpa, f.snapshots(), .{ .min_prompt = 0 }, 1 << 20);
    defer s.deinit();
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 6 };
    _ = f.pass(&s, &t1, try s.begin(a, &t1, 4, &.{}, &.{}, null));
    try std.testing.expectEqual(@as(usize, 0), s.entries.items.len);
    try std.testing.expectEqual(@as(u64, 1), s.counts.failed);
    f.fail_save = false;
    _ = f.pass(&s, &t1, try s.begin(a, &t1, 4, &.{}, &.{}, null));
    try std.testing.expectEqual(@as(usize, 1), s.entries.items.len);
    f.fail_restore = true;
    const t2 = [_]u32{ 1, 2, 3, 4, 5, 6, 7 };
    const p = try s.begin(a, &t2, 6, &.{}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 0), p.from);
    try std.testing.expectEqual(@as(usize, 0), s.entries.items.len); // the entry that failed is gone
    try std.testing.expectEqual(fresh(&t2), f.pass(&s, &t2, p));
}

test "marks: the stable prefix with the last prompt and shared blocks, past the resume point, before the end" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .lookahead = 1, .min_gap = 2, .min_prompt = 0 }, 1 << 20);
    defer s.deinit();
    const prompt = [_]u32{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
    const prev = [_]u32{ 1, 2, 3, 4, 5, 6, 7, 0, 0 };
    try std.testing.expectEqualSlices(u32, &.{ 3, 7, 10 }, try s.marks(a, &prompt, 0, 10, &.{ 3, 12, 0 }, &.{}, &prev));
    try std.testing.expectEqualSlices(u32, &.{10}, try s.marks(a, &prompt, 7, 10, &.{3}, &.{}, &prev));
    try std.testing.expectEqualSlices(u32, &.{}, try s.marks(a, &prompt, 0, 0, &.{}, &.{}, &.{})); // a raw prompt keeps nothing
    try std.testing.expectEqualSlices(u32, &.{10}, try s.marks(a, &prompt, 0, 10, &.{9}, &.{}, &.{})); // a block next to the history
}

test "prompts under min_prompt keep nothing (their extra prompt call would cost more than reuse saves), longer ones keep as before" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .lookahead = 1, .min_prompt = 8 }, 1 << 20);
    defer s.deinit();
    const short = [_]u32{ 1, 2, 3, 4, 5, 9, 9 }; // 7 tokens, history 5
    const p = try s.begin(a, &short, 5, &.{}, &.{}, null);
    try std.testing.expectEqualSlices(u32, &.{}, p.marks);
    try std.testing.expectEqual(fresh(&short), f.pass(&s, &short, p));
    try std.testing.expectEqual(@as(usize, 0), s.entries.items.len);
    const long = [_]u32{ 1, 2, 3, 4, 5, 9, 7, 7, 9, 9 }; // 10 tokens: the next turn keeps its history, resuming nothing
    const q = try s.begin(a, &long, 8, &.{}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 0), q.from);
    try std.testing.expectEqualSlices(u32, &.{8}, q.marks);
    try std.testing.expectEqual(fresh(&long), f.pass(&s, &long, q));
    try std.testing.expectEqual(@as(u32, 8), s.find(&.{ 1, 2, 3, 4, 5, 9, 7, 7, 9, 9, 4 }, &.{}).?.at);
}

test "kept states charge their real storage, a save takes spare storage first, and spare stays inside the budget" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.pooled(), .{ .min_prompt = 0 }, 330); // new storage 100 + at, a kept state 90 + at
    defer s.deinit();
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 6 };
    _ = f.pass(&s, &t1, try s.begin(a, &t1, 4, &.{}, &.{}, null));
    try std.testing.expectEqual(@as(u64, 94), s.held);
    f.spare_bytes = 120; // a buffer readied while idle
    try std.testing.expectEqual(@as(u64, 116), s.room());
    const other = [_]u32{ 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };
    _ = f.pass(&s, &other, try s.begin(a, &other, 10, &.{}, &.{}, null)); // takes the readied buffer: nothing evicted
    try std.testing.expectEqual(@as(u64, 194), s.held);
    try std.testing.expectEqual(@as(u64, 20), s.spare());
    try std.testing.expectEqual(@as(u64, 0), s.counts.evicted);
    var t2: [102]u32 = undefined;
    for (&t2, 1..) |*t, i| t.* = @intCast(i);
    _ = f.pass(&s, &t2, try s.begin(a, &t2, 101, &.{}, &.{}, null)); // resumes t1's; 201 new: the spare shrinks, then `other` goes
    try std.testing.expectEqual(@as(u64, 1), s.counts.evicted);
    try std.testing.expectEqual(@as(u64, 94 + 191), s.held);
    try std.testing.expect(s.held + s.spare() <= s.budget);
    try std.testing.expectEqual(s.entries.items.len, f.live);
}

test "a shared system cut outlives its own conversation's turns: a second conversation resumes it after cold prompts fill the budget" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .min_prompt = 0, .min_gap = 1 }, 600); // bytes 100 + at
    defer s.deinit();
    var c1: [30]u32 = @splat(9);
    var c2: [30]u32 = @splat(8);
    for ([_][]u32{ &c1, &c2 }) |c| { // cold prompts first
        _ = f.pass(&s, c, try s.begin(a, c, 29, &.{}, &.{}, null));
        try std.testing.expect(s.held <= s.budget);
    }
    var conv: [45]u32 = undefined;
    for (&conv, 1..) |*t, i| t.* = @intCast(i); // a 20-token system block, then the turns
    for ([_]u32{ 25, 35, 45 }, [_]u32{ 24, 34, 44 }) |len, history| {
        _ = f.pass(&s, conv[0..len], try s.begin(a, conv[0..len], history, &.{20}, &.{}, null));
        try std.testing.expect(s.held <= s.budget);
    }
    var c3: [60]u32 = @splat(7);
    _ = f.pass(&s, &c3, try s.begin(a, &c3, 59, &.{}, &.{}, null));
    try std.testing.expect(s.held <= s.budget);
    var other: [25]u32 = undefined;
    @memcpy(other[0..20], conv[0..20]);
    for (other[20..], 0..) |*t, i| t.* = @intCast(90 + i);
    const plan = try s.begin(a, &other, 24, &.{20}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 20), plan.from); // the cut survived the first conversation's turns
    try std.testing.expectEqual(fresh(&other), f.pass(&s, &other, plan));
    try std.testing.expect(s.held <= s.budget);
}

test "a pass makes room for every state it keeps before it starts, so a peer told of the evictions with the request stays inside the budget" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var peer: Peer = .{};
    var f: Fake = .{ .gpa = gpa, .peer = &peer };
    var s = Store.init(gpa, f.snapshots(), .{ .min_prompt = 0, .min_gap = 1 }, 600); // bytes 100 + at
    defer s.deinit();
    var conv: [200]u32 = undefined;
    for (&conv, 1..) |*t, i| t.* = @intCast(i);
    var len: u32 = 30;
    while (len <= 200) : (len += 17) { // a conversation's turns: each keeps its history and the stable prefix, two states a pass
        peer.request(); // the drops the last pass made reach the peer with this request
        const plan = try s.begin(a, conv[0..len], len - 3, &.{20}, &.{}, null); // its own evictions too, before the peer keeps anything
        _ = f.pass(&s, conv[0..len], plan);
        try std.testing.expect(s.held <= s.budget);
    }
    try std.testing.expect(s.counts.evicted > 0);
    try std.testing.expect(peer.max <= s.budget); // evicting at keep time instead, the peer holds the old states until the next request
}

test "a state a peer cannot resume is forgotten: the next prompt misses instead of asking again" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.snapshots(), .{ .min_prompt = 0 }, 1000);
    defer s.deinit();
    const t1 = [_]u32{ 1, 2, 3, 4, 5, 6 };
    _ = f.pass(&s, &t1, try s.begin(a, &t1, 4, &.{}, &.{}, null));
    const t2 = [_]u32{ 1, 2, 3, 4, 5, 6, 7, 8 };
    const plan = try s.begin(a, &t2, 6, &.{}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 4), plan.from);
    s.forget(&t2, plan.from); // the peer's answer: it lacks that state
    try std.testing.expectEqual(@as(u64, 1), s.counts.failed);
    try std.testing.expectEqual(@as(?*pc.Entry, null), s.find(&t2, &.{}));
    try std.testing.expectEqual(s.entries.items.len, f.live);
}

test "a learned harness state outlives its store: a fresh session on a new one resumes it from disk, equal to a fresh pass" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var root_buf: [128]u8 = undefined;
    const root = try std.fmt.bufPrint(&root_buf, "/tmp/tf-learn-test-{d}", .{std.c.getpid()});
    const rules: pc.Rules = .{ .lookahead = 1, .min_prompt = 0, .min_gap = 1 };
    const harness = [_]u32{ 7, 7, 7, 7, 7, 7 }; // shared by every session: a state at 5 reads it all (lookahead 1)
    const key = imprint.Imprint.keyOf(&harness);
    defer rmTree(root);
    {
        var im = try imprint.Imprint.open(gpa, root, 3, 1 << 30);
        defer im.deinit();
        {
            var f: Fake = .{ .gpa = gpa };
            var s = Store.init(gpa, f.learned(), rules, 1 << 20);
            defer s.deinit();
            s.imprint = &im;
            const first = harness ++ [_]u32{ 1, 2, 9 };
            try std.testing.expectEqual(fresh(&first), f.pass(&s, &first, try s.begin(a, &first, 8, &.{5}, &.{}, null)));
            try std.testing.expect(im.has(key));
        }
        var again = try imprint.Imprint.open(gpa, root, 3, 1 << 30); // a new server reads the index back
        defer again.deinit();
        var f: Fake = .{ .gpa = gpa };
        var s = Store.init(gpa, f.learned(), rules, 1 << 20);
        defer s.deinit();
        s.imprint = &again;
        const second = harness ++ [_]u32{ 3, 4, 9 };
        const ns = pc.namespaceFor("private-cold-test");
        const salted = try s.lookupScoped(ns, a, &second, 8, &.{5}, &.{});
        try std.testing.expect(salted.entry == null); // never recall the learned unsalted harness
        const other = [_]u32{ 8, 8, 8, 8, 8, 8, 3, 4, 9 };
        _ = try s.lookupScoped(ns, a, &other, 8, &.{5}, &.{});
        f.at = 5;
        f.sum = fresh(other[0..5]);
        try std.testing.expect(s.keepScoped(ns, &other, 5, null, &.{}));
        try std.testing.expect(!again.has(imprint.Imprint.keyOf(other[0..6]))); // never learn salted states into unsalted files
        const p = try s.begin(a, &second, 8, &.{5}, &.{}, null);
        try std.testing.expectEqual(@as(u32, 5), p.from);
        try std.testing.expectEqual(fresh(&second), f.pass(&s, &second, p));
    }
}

test "past the learned-state cap the least recently used state is forgotten, and a file that no longer reads is too" {
    const gpa = std.testing.allocator;
    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var root_buf: [128]u8 = undefined;
    const root = try std.fmt.bufPrint(&root_buf, "/tmp/tf-learn-cap-{d}", .{std.c.getpid()});
    defer rmTree(root);
    const rules: pc.Rules = .{ .lookahead = 1, .min_prompt = 0, .min_gap = 1 };
    const one = [_]u32{ 7, 7, 7, 7, 7, 7 };
    const two = [_]u32{ 8, 8, 8, 8, 8, 8 };
    var im = try imprint.Imprint.open(gpa, root, 3, 150); // a state at 5 is 105 bytes: one fits
    defer im.deinit();
    var f: Fake = .{ .gpa = gpa };
    var s = Store.init(gpa, f.learned(), rules, 1 << 20);
    defer s.deinit();
    s.imprint = &im;
    const p1 = one ++ [_]u32{ 1, 9 };
    try std.testing.expectEqual(fresh(&p1), f.pass(&s, &p1, try s.begin(a, &p1, 7, &.{5}, &.{}, null)));
    const p2 = two ++ [_]u32{ 1, 9 };
    try std.testing.expectEqual(fresh(&p2), f.pass(&s, &p2, try s.begin(a, &p2, 7, &.{5}, &.{}, null)));
    try std.testing.expect(im.has(imprint.Imprint.keyOf(&two)) and !im.has(imprint.Imprint.keyOf(&one)));
    var path: [512]u8 = undefined;
    try std.testing.expect(std.c.unlink(try Fake.file(&path, im.dir, imprint.Imprint.keyOf(&one))) != 0); // its file went too
    _ = std.c.unlink(try Fake.file(&path, im.dir, imprint.Imprint.keyOf(&two))); // a file lost behind the store's back
    var g: Fake = .{ .gpa = gpa };
    var t = Store.init(gpa, g.learned(), rules, 1 << 20);
    defer t.deinit();
    t.imprint = &im;
    const p3 = two ++ [_]u32{ 2, 9 };
    const plan = try t.begin(a, &p3, 7, &.{5}, &.{}, null);
    try std.testing.expectEqual(@as(u32, 0), plan.from); // the read failed: a fresh pass, and the state is forgotten
    try std.testing.expect(!im.has(imprint.Imprint.keyOf(&two)));
    try std.testing.expectEqual(fresh(&p3), g.pass(&t, &p3, plan));
    try std.testing.expect(im.has(imprint.Imprint.keyOf(&two))); // learned again by that pass
}

const Residency = struct {
    fn live(_: *anyopaque, saved: Saved) bool {
        const s: *Fake.State = @ptrCast(@alignCast(saved));
        return s.sum != std.math.maxInt(u64);
    }
    fn compatible(_: *anyopaque, saved: Saved, len: usize) bool {
        const s: *Fake.State = @ptrCast(@alignCast(saved));
        return s.at == len or s.at <= len -| 2;
    }
};

test "physical eviction cannot hide a shorter live prefix or survive a repeated save" {
    const a = std.testing.allocator;
    var f: Fake = .{ .gpa = a };
    var s = Store.init(a, .{ .ptr = &f, .vtable = &.{ .bytes = Fake.bytesFn, .save = Fake.saveFn, .restore = Fake.restoreFn, .drop = Fake.dropFn, .live = Residency.live, .compatible = Residency.compatible } }, .{ .exact_end = true }, 4096);
    defer s.deinit();
    const tokens = [_]u32{ 1, 2, 3, 4, 5, 6 };
    for ([_]u32{ 2, 4 }) |at| {
        f.at = at;
        f.sum = fresh(tokens[0..at]);
        try std.testing.expect(s.keep(&tokens, at, null, &.{}));
    }
    const st: *Fake.State = @ptrCast(@alignCast(s.find(&tokens, &.{}).?.saved));
    st.sum = std.math.maxInt(u64);
    try std.testing.expectEqual(@as(u32, 2), s.find(&tokens, &.{}).?.at);
    f.at = 4;
    f.sum = fresh(tokens[0..4]);
    try std.testing.expect(s.keep(&tokens, 4, null, &.{}));
    try std.testing.expectEqual(@as(usize, 2), s.entries.items.len);
    try std.testing.expectEqual(@as(u32, 4), s.find(&tokens, &.{}).?.at);
    // Exact-length reuse is explicit and remains namespace-isolated.
    try std.testing.expectEqual(@as(u32, 4), s.find(tokens[0..4], &.{}).?.at);
    try std.testing.expect(s.findScoped(pc.namespaceFor("unrelated"), tokens[0..4], &.{}) == null);
    // A longer but incompatible entry must not shadow the usable shorter one.
    try std.testing.expectEqual(@as(u32, 2), s.find(tokens[0..5], &.{}).?.at);
    s.rules.exact_end = false;
    try std.testing.expectEqual(@as(u32, 2), s.find(tokens[0..4], &.{}).?.at);
}

const TerminalUpgrade = struct {
    fn compatible(_: *anyopaque, saved: Saved, len: usize) bool {
        const s: *Fake.State = @ptrCast(@alignCast(saved));
        return (s.at == len and s.sum == 1) or s.at <= len -| 2;
    }
};

test "a complete terminal state upgrades a live encoder-only token-key duplicate" {
    const a = std.testing.allocator;
    var f: Fake = .{ .gpa = a };
    var s = Store.init(a, .{ .ptr = &f, .vtable = &.{ .bytes = Fake.bytesFn, .save = Fake.saveFn, .restore = Fake.restoreFn, .drop = Fake.dropFn, .compatible = TerminalUpgrade.compatible } }, .{ .exact_end = true }, 4096);
    defer s.deinit();
    const tokens = [_]u32{ 1, 2, 3, 4, 5, 6 };
    f.at = 4;
    f.sum = 0; // encoder-only state retained while filling the longer request
    try std.testing.expect(s.keep(&tokens, 4, null, &.{}));
    try std.testing.expect(s.find(tokens[0..4], &.{}) == null);
    f.sum = 1; // the shorter request has now fully computed its head
    try std.testing.expect(s.keep(tokens[0..4], 4, null, &.{}));
    try std.testing.expect(s.find(tokens[0..4], &.{}) != null);
    try std.testing.expectEqual(@as(usize, 1), s.entries.items.len);
    // A later encoder save of the longer request must not downgrade it.
    f.sum = 0;
    try std.testing.expect(s.keep(&tokens, 4, null, &.{}));
    try std.testing.expect(s.find(tokens[0..4], &.{}) != null);
    try std.testing.expect(s.findScoped(pc.namespaceFor("other"), tokens[0..4], &.{}) == null);
}
